// record should not be infected!
public record Rec(int a, int b) {

}
