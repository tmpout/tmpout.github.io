class NamingConflicts {
  static void main() {
    var x = new NamingConflicts();
    x.entry();
  }
  // This method conflicts with the initial entrypoint name. Since all methods are renamed this isn't a problem.
  public void entry() {
    System.out.println("entry");
  }
}
