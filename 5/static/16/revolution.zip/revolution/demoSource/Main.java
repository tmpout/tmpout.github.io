// easy to infect, entrypoint will be injected either into `main`, `foo`, `bar` or the empty default constructor
class Main {
  static void main(String[] args) {
    System.out.println("hello world");
    var m = new Main();
    m.foo();
    m.bar();
  }

  void foo() {
    System.out.println("foo");
  }

  void bar() {
    System.out.println("bar");
  }
}
