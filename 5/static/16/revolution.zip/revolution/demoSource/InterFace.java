// interfaces cannot get infected
public interface InterFace {
  int wat();
}
