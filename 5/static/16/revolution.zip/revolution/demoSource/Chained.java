public class Chained {
  static void main() {
    System.out.println(a(0));
  }
  static int a(int v) {
    return b(v + 1);
  }
  static int b(int v) {
    return c(v + 1);
  }
  static int c(int v) {
    return v;
  }
}
