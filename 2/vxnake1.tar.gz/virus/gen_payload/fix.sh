#!/bin/bash

#strip shstrtab section and section headers
dd if=./politic of=./TMPolitic bs=1 \
    count=$(readelf -S politic | grep shstrtab | awk '{print "0x"$6}' | printf "%d" $(cat /dev/stdin))

#ehdr->e_shnum = 0;
#ehdr->e_shstrndx = 0;
printf "\x00\x00\x00\x00" \
    | dd if=/dev/stdin of=./TMPolitic seek=60 bs=1 count=4 conv=notrunc

#ehdr->e_shoff = 0;
printf "\x00\x00\x00\00\x00\x00\x00\00" \
    | dd if=/dev/stdin of=./TMPolitic seek=40 bs=1 count=8 conv=notrunc

readelf -h TMPolitic | grep Entry | awk '{print $4}' |\
 printf "unsigned long politic_entry = 0x%x;\x0a" $(($(cat /dev/stdin)-(64+2*56)-0x400000)) > politic.h

dd if=./TMPolitic of=./politic skip=$((64+2*56)) bs=1

chmod +x politic
xxd -i politic >> politic.h
