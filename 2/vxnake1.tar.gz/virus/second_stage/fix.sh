#!/bin/bash

#strip shstrtab section and section headers
dd if=./payload of=./TMpayload bs=1 \
    count=$(readelf -S payload | grep shstrtab | awk '{print "0x"$6}' | printf "%d" $(cat /dev/stdin))

#ehdr->e_shnum = 0;
#ehdr->e_shstrndx = 0;
printf "\x00\x00\x00\x00" \
    | dd if=/dev/stdin of=./TMpayload seek=60 bs=1 count=4 conv=notrunc

#ehdr->e_shoff = 0;
printf "\x00\x00\x00\00\x00\x00\x00\00" \
    | dd if=/dev/stdin of=./TMpayload seek=40 bs=1 count=8 conv=notrunc

readelf -h TMpayload | grep Entry | awk '{print $4}' |\
 printf "unsigned long payload_entry = 0x%x;\x0a" $(($(cat /dev/stdin)-(64+2*56)-0x400000)) > payload.h

dd if=./TMpayload of=./payload skip=$((64+2*56)) bs=1

chmod +x payload
xxd -i payload >> payload.h
