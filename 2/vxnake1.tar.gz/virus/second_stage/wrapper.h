__attribute__((naked)) long syscall6(long p1, long p2, long p3, long p4,
                                     long p5, long p6, long syscall)
{
    __asm__(
        "mov 8(%rsp), %rax\n"
        "mov %rcx, %r10\n"
        "syscall\n"
        "ret");
}

__attribute__((naked)) long syscall5(long p1, long p2, long p3, long p4,
                                     long p5, long syscall)
{
    __asm__(
        "mov %r9, %rax\n"
        "mov %rcx, %r10\n"
        "syscall\n"
        "ret");
}

__attribute__((naked)) long syscall4(long p1, long p2, long p3, long p4, long syscall)
{
    __asm__(
        "mov %r8, %rax\n"
        "mov %rcx, %r10\n"
        "syscall\n"
        "ret");
}

__attribute__((naked)) long syscall3(long p1, long p2, long p3, long syscall)
{
    __asm__(
        "mov %rcx, %rax\n"
        "syscall\n"
        "ret");
}

__attribute__((naked)) long syscall2(long p1, long p2, long syscall)
{
    __asm__(
        "mov %rdx, %rax\n"
        "syscall\n"
        "ret");
}

__attribute__((naked)) long syscall1(long p1, long syscall)
{
    __asm__(
        "mov %rsi, %rax\n"
        "syscall\n"
        "ret");
}

__attribute__((naked)) long syscall0(long syscall)
{
    __asm__(
        "mov %rdi, %rax\n"
        "syscall\n"
        "ret");
}

//sys_read
#define __NR_READ 0x0
#define read(p1, p2, p3) syscall3(p1, p2, p3, __NR_READ)

//sys_write
#define __NR_WRITE 0x1
#define write(p1, p2, p3) syscall3(p1, p2, p3, __NR_WRITE)

//sys_open
#define O_RDONLY 00000000
#define O_WRONLY 00000001
#define O_RDWR 00000002
#define O_CREAT 00000100
#define O_TRUNC 00001000

#define __S_ISUID 04000    /* Set user ID on execution.  */
#define __S_ISGID 02000    /* Set group ID on execution.  */
#define __S_ISVTX 01000    /* Save swapped text after use (sticky).  */
#define __S_IREAD 0400     /* Read by owner.  */
#define __S_IWRITE 0200    /* Write by owner.  */
#define __S_IEXEC 0100     /* Execute by owner.  */
#define S_IRUSR __S_IREAD  /* Read by owner.  */
#define S_IWUSR __S_IWRITE /* Write by owner.  */
#define S_IXUSR __S_IEXEC  /* Execute by owner.  */

#define __NR_OPEN 2
#define open(p1, p2, p3) syscall3(p1, p2, p3, __NR_OPEN)

//sys_close
#define __NR_CLOSE 3
#define close(p1) syscall1(p1, __NR_CLOSE)

//sys_fstat
struct stat
{
    unsigned long st_dev;
    unsigned long st_ino;
    unsigned long st_nlink;
    unsigned int st_mode;
    unsigned int st_uid;
    unsigned int st_gid;
    unsigned int __pad0;
    unsigned long st_rdev;
    long st_size;
    long st_blksize;
    long st_blocks;
    unsigned long st_atime;
    unsigned long st_atime_nsec;
    unsigned long st_mtime;
    unsigned long st_mtime_nsec;
    unsigned long st_ctime;
    unsigned long st_ctime_nsec;
    long __unused[3];
};

#define __NR_FSTAT 5
#define fstat(p1, p2) syscall2(p1, p2, __NR_FSTAT)

//sys_lseek
#define SEEK_SET 0 /* Seek from beginning of file.  */
#define SEEK_CUR 1 /* Seek from current position.  */
#define SEEK_END 2 /* Seek from end of file.  */

#define __NR_LSEEK 8
#define lseek(p1, p2, p3) syscall3(p1, p2, p3, __NR_LSEEK)

//sys_mmap
#define PROT_READ 0x1             /* page can be read */
#define PROT_WRITE 0x2            /* page can be written */
#define PROT_EXEC 0x4             /* page can be executed */
#define PROT_SEM 0x8              /* page may be used for atomic ops */
#define PROT_NONE 0x0             /* page can not be accessed */
#define PROT_GROWSDOWN 0x01000000 /* mprotect flag: extend change to start of growsdown vma */
#define PROT_GROWSUP 0x02000000   /* mprotect flag: extend change to end of growsup vma */

/* 0x01 - 0x03 are defined in linux/mman.h */
#define MAP_TYPE 0x0f            /* Mask for type of mapping */
#define MAP_FIXED 0x10           /* Interpret addr exactly */
#define MAP_ANONYMOUS 0x20       /* don't use a file */
#define MAP_SHARED 0x01          /* Share changes */
#define MAP_PRIVATE 0x02         /* Changes are private */
#define MAP_SHARED_VALIDATE 0x03 /* share + validate extension flags */

/* 0x0100 - 0x4000 flags are defined in asm-generic/mman.h */
#define MAP_POPULATE 0x008000        /* populate (prefault) pagetables */
#define MAP_NONBLOCK 0x010000        /* do not block on IO */
#define MAP_STACK 0x020000           /* give out an address that is best suited for process/thread stacks */
#define MAP_HUGETLB 0x040000         /* create a huge page mapping */
#define MAP_SYNC 0x080000            /* perform synchronous page faults for the mapping */
#define MAP_FIXED_NOREPLACE 0x100000 /* MAP_FIXED which doesn't unmap underlying mapping */

#define MAP_UNINITIALIZED 0x4000000 /* For anonymous mmap, memory could be \
                                     * uninitialized                       \
                                     */

#define __NR_MMAP 0x9
#define mmap(p1, p2, p3, p4, p5, p6) syscall6(p1, p2, p3, p4, p5, p6, __NR_MMAP)

#define __NR_MUNMAP 11
#define munmap(p1,p2) syscall2(p1,p2, __NR_MUNMAP)

//sys_clone
#define __NR_CLONE 56
#define clone(p1, p2, p3, p4, p5) syscall5(p1, p2, p3, p4, p5, __NR_CLONE)

//sys_execve
#define __NR_EXECVE 59
#define execve(p1,p2,p3) syscall3(p1,p2,p3,__NR_EXECVE)

//sys_exit
#define __NR_EXIT 60
#define exit(p1) syscall1(p1, __NR_EXIT)

//sys_wait4
#define __WALL          0x40000000
#define __NR_WAIT4 61
#define wait4(p1,p2,p3,p4) syscall4(p1,p2,p3,p4,__NR_WAIT4)

//sys_rename
#define __NR_RENAME 82
#define rename(p1, p2) syscall2(p1, p2, __NR_RENAME)

//sys_getdents64
struct linux_dirent64
{
    unsigned long d_ino;           /* 64-bit inode number */
    unsigned long d_off;           /* 64-bit offset to next structure */
    unsigned short d_reclen; /* Size of this dirent */
    unsigned char d_type;    /* File type */
    char d_name[];           /* Filename (null-terminated) */
};
/* File types for `d_type'.  */
enum
  { 
    DT_UNKNOWN = 0,
# define DT_UNKNOWN     DT_UNKNOWN
    DT_FIFO = 1,
# define DT_FIFO        DT_FIFO
    DT_CHR = 2,
# define DT_CHR         DT_CHR
    DT_DIR = 4,
# define DT_DIR         DT_DIR
    DT_BLK = 6,
# define DT_BLK         DT_BLK
    DT_REG = 8,
# define DT_REG         DT_REG
    DT_LNK = 10,
# define DT_LNK         DT_LNK
    DT_SOCK = 12,
# define DT_SOCK        DT_SOCK
    DT_WHT = 14
# define DT_WHT         DT_WHT
  };

#define __NR_GETDENTS64 217
#define getdents64(p1,p2,p3) syscall3(p1,p2,p3,__NR_GETDENTS64)


#define __NR_MEMFD_CREATE 319
#define memfd_create(p1,p2) syscall2(p1,p2,__NR_MEMFD_CREATE)

#define NULL ((void *)0L)
