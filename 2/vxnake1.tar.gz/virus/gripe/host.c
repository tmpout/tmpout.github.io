#include <stdio.h>

int main(int ac, char **av)
{
    printf("Hello im %s\n", av[0]);
	for (int i = 1; i < ac; i++)
	printf("av[%d] = %s\n", i, av[i]);
    return 0;
}
