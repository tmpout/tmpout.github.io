package edu.vx;

public enum TestEnum {
  A,
  B;
}
