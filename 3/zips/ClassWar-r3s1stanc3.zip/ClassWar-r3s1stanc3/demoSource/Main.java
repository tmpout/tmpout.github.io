public class Main {
  public static void main(String[] args) {
    System.out.println("hello from victim");
    System.out.println(Util.add(3, 4));
  }
}
